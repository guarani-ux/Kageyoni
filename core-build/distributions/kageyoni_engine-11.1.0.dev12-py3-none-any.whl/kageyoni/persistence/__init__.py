"""Local durable storage boundaries."""
